package com.furan.living.commodity.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.renren.common.utils.PageUtils;
import io.renren.common.utils.Query;

import com.furan.living.commodity.dao.IncomeExpenseDao;
import com.furan.living.commodity.entity.IncomeExpenseEntity;
import com.furan.living.commodity.service.IncomeExpenseService;


@Service("incomeExpenseService")
public class IncomeExpenseServiceImpl extends ServiceImpl<IncomeExpenseDao, IncomeExpenseEntity> implements IncomeExpenseService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        IPage<IncomeExpenseEntity> page = this.page(
                new Query<IncomeExpenseEntity>().getPage(params),
                new QueryWrapper<IncomeExpenseEntity>()
        );

        return new PageUtils(page);
    }

}
